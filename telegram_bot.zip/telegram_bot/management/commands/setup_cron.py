from django.core.management.base import BaseCommand
from django.conf import settings


class Command(BaseCommand):
    help = "Cron job sozlaş uçun yöriqnoma körsatiş"

    def handle(self, *args, **options):
        site_url = getattr(settings, 'SITE_URL', 'https://itcreative.uz').rstrip('/')

        self.stdout.write(self.style.SUCCESS("""
╔══════════════════════════════════════════════════════╗
║  TELEGRAM BOT KEEP-ALIVE SOZLAŞ                     ║
╚══════════════════════════════════════════════════════╝

Bot töxtab qolmasligi uçun quyidagi usullardan BIRINI tanlang:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1-USUL: CRON JOB (tavsiya etiladi)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Hosting panelingizda Cron Jobs bölimiga kiring va
har 5 daqiqada işlaydigan cron qöşing:

  */5 * * * * curl -s {site_url}/telegrambotlms/health/ > /dev/null 2>&1

Yoki Django management command bilan:

  */5 * * * * cd /path/to/project && python manage.py keep_bot_alive --once

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2-USUL: TAŞQI MONITORING XIZMATLARI (bepul)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Quyidagi bepul xizmatlardan foydalaning:

a) UptimeRobot (https://uptimerobot.com):
   - Röyxatdan öting
   - "Add New Monitor" bosing
   - Monitor Type: HTTP(s)
   - URL: {site_url}/telegrambotlms/health/
   - Monitoring Interval: 5 minutes

b) cron-job.org (https://cron-job.org):
   - Röyxatdan öting
   - "Create Cronjob" bosing
   - URL: {site_url}/telegrambotlms/health/
   - Schedule: Har 5 daqiqada

c) Freshping (https://freshping.io):
   - Bepul 50 ta check
   - URL: {site_url}/telegrambotlms/health/

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ESLATMA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Health check URL: {site_url}/telegrambotlms/health/
Webhook URL: {site_url}/telegrambotlms/webhook/
""".format(site_url=site_url)))
