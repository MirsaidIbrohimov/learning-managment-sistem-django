import math
from datetime import timedelta

from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Sum, Q
from django.db import transaction
from django.shortcuts import get_object_or_404
from django.utils import timezone

from coin.models import Product, ProductLike, ProductComment, ProductPurchase, CoinTransaction, ActivityLog
from accounts.models import CustomUser, PremiumRequest, Message
from telegram_bot.utils import notify_group, notify_user, notify_admins
from .serializers import (
    ProductSerializer, ProductCommentSerializer, ProductPurchaseSerializer,
    CoinTransactionSerializer, ActivityLogSerializer, CoinSummarySerializer,
    ProductCommentCreateSerializer, PremiumRequestSerializer,
)

PREMIUM_DISCOUNT = 0.05

PREMIUM_PLANS = {
    'weekly': {'name': 'Haftalik', 'price': 350, 'days': 7},
    'monthly': {'name': '1 oylik', 'price': 700, 'days': 30},
    'bimonthly': {'name': '2 oylik', 'price': 1000, 'days': 60},
}


def get_discounted_price(product, user):
    if user.is_premium:
        return math.floor(product.coin_price * (1 - PREMIUM_DISCOUNT))
    return product.coin_price


class ProductListView(generics.ListAPIView):
    serializer_class = ProductSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = Product.objects.filter(is_active=True).order_by('-created_at')
        search = self.request.query_params.get('search', '')
        if search:
            qs = qs.filter(Q(name__icontains=search) | Q(description__icontains=search))
        return qs


class ProductDetailView(generics.RetrieveAPIView):
    serializer_class = ProductSerializer
    permission_classes = [IsAuthenticated]
    queryset = Product.objects.filter(is_active=True)


class ProductCommentsView(generics.ListAPIView):
    serializer_class = ProductCommentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return ProductComment.objects.filter(product_id=self.kwargs['pk']).select_related('user')


class MyPurchasesView(generics.ListAPIView):
    serializer_class = ProductPurchaseSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = ProductPurchase.objects.filter(user=self.request.user).select_related('product')
        status_filter = self.request.query_params.get('status', '')
        if status_filter:
            qs = qs.filter(status=status_filter)
        return qs


class CoinTransactionListView(generics.ListAPIView):
    serializer_class = CoinTransactionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = CoinTransaction.objects.filter(user=self.request.user)
        action = self.request.query_params.get('action', '')
        if action:
            qs = qs.filter(action=action)
        search = self.request.query_params.get('search', '')
        if search:
            qs = qs.filter(reason__icontains=search)
        date_from = self.request.query_params.get('date_from', '')
        if date_from:
            qs = qs.filter(created_at__date__gte=date_from)
        date_to = self.request.query_params.get('date_to', '')
        if date_to:
            qs = qs.filter(created_at__date__lte=date_to)
        return qs


class ActivityLogListView(generics.ListAPIView):
    serializer_class = ActivityLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = ActivityLog.objects.filter(user=self.request.user)
        action_type = self.request.query_params.get('action_type', '')
        if action_type:
            qs = qs.filter(action_type=action_type)
        return qs


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def coin_summary(request):
    user = request.user
    transactions = CoinTransaction.objects.filter(user=user)
    total_earned = transactions.filter(action='add').aggregate(total=Sum('amount'))['total'] or 0
    total_spent = transactions.filter(action__in=['remove', 'purchase']).aggregate(total=Sum('amount'))['total'] or 0
    data = {
        'total_coins': user.coins,
        'total_earned': total_earned,
        'total_spent': total_spent,
        'total_transactions': transactions.count(),
        'is_premium': user.is_premium,
    }
    serializer = CoinSummarySerializer(data)
    return Response(serializer.data)


# ============== WRITE ENDPOINTS ==============


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def toggle_like(request, pk):
    product = get_object_or_404(Product, pk=pk)
    like = ProductLike.objects.filter(product=product, user=request.user).first()

    if like:
        coin_back = 2 if request.user.is_premium else 1
        if like.coin_awarded:
            request.user.remove_coins(coin_back, f"Mahsulotga like bekor qilindi: {product.name}")
        like.delete()
        return Response({'liked': False, 'likes_count': product.likes_count})
    else:
        coin_amount = 2 if request.user.is_premium else 1
        like = ProductLike.objects.create(product=product, user=request.user, coin_awarded=True)
        request.user.add_coins(coin_amount, f"Mahsulotga like: {product.name}")
        ActivityLog.objects.create(
            user=request.user,
            action_type='like_product',
            description=f"Mahsulotga like bosdi: {product.name} (+{coin_amount} coin)"
        )
        return Response({'liked': True, 'likes_count': product.likes_count}, status=status.HTTP_201_CREATED)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def purchase_product(request, pk):
    product = get_object_or_404(Product, pk=pk)
    final_price = get_discounted_price(product, request.user)
    has_discount = request.user.is_premium and final_price < product.coin_price

    if request.user.coins < final_price:
        return Response({'error': "Coinlaringiz yetarli emas!"}, status=status.HTTP_400_BAD_REQUEST)

    if product.stock <= 0:
        return Response({'error': "Mahsulot tugagan!"}, status=status.HTTP_400_BAD_REQUEST)

    with transaction.atomic():
        request.user.coins -= final_price
        request.user.save(update_fields=['coins'])

        product.stock -= 1
        product.save()

        purchase = ProductPurchase.objects.create(
            product=product,
            user=request.user,
            coins_spent=final_price
        )

        discount_label = " (Premium -5%)" if has_discount else ""
        CoinTransaction.objects.create(
            user=request.user,
            amount=final_price,
            action='remove',
            reason=f"Mahsulot sotib olindi: {product.name}{discount_label}"
        )
        ActivityLog.objects.create(
            user=request.user,
            action_type='purchase_product',
            description=f"Mahsulot sotib oldi: {product.name} ({final_price} coin{discount_label})"
        )

        notify_admins(
            f"🛒 <b>Yangi buyurtma!</b>\n\n"
            f"👤 <b>{request.user.full_name}</b> (@{request.user.username})\n"
            f"📦 Mahsulot: <b>{product.name}</b>\n"
            f"🪙 Narxi: <b>{final_price}</b> coin{discount_label}\n"
            f"📊 Qolgan: {product.stock} ta\n\n"
            f"📋 Buyurtma #{purchase.pk}"
        )

        if request.user.telegram_id:
            notify_user(
                request.user.telegram_id,
                f"✅ <b>Buyurtmangiz qabul qilindi!</b>\n\n"
                f"📦 <b>{product.name}</b>\n"
                f"🪙 Narxi: <b>{final_price}</b> coin\n\n"
                f"📋 Buyurtma #{purchase.pk}\n"
                f"⏳ Holat: Kutilmoqda\n\n"
                f"❌ Bekor qilish uchun saytga kiring."
            )

        Message.objects.create(
            recipient=request.user,
            title=f"✅ Buyurtma #{purchase.pk} qabul qilindi",
            content=f"Siz '{product.name}' mahsulotini {final_price} coin ga sotib oldingiz. Buyurtmangiz kutilmoqda. Agar bekor qilmoqchi bo'lsangiz, 'Mening xaridlarim' bo'limiga o'ting.",
            message_type='system'
        )

    serializer = ProductPurchaseSerializer(purchase)
    return Response(serializer.data, status=status.HTTP_201_CREATED)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def cancel_purchase(request, pk):
    purchase = get_object_or_404(ProductPurchase, pk=pk, user=request.user)

    if not purchase.can_cancel:
        return Response({'error': "Bu buyurtmani bekor qilib bo'lmaydi!"}, status=status.HTTP_400_BAD_REQUEST)

    with transaction.atomic():
        purchase.user.coins += purchase.coins_spent
        purchase.user.save(update_fields=['coins'])

        purchase.product.stock += 1
        purchase.product.save()

        purchase.status = 'cancelled'
        purchase.cancelled_at = timezone.now()
        purchase.save()

        CoinTransaction.objects.create(
            user=purchase.user,
            amount=purchase.coins_spent,
            action='add',
            reason=f"Buyurtma bekor qilindi: {purchase.product.name} (#{purchase.pk})"
        )

        ActivityLog.objects.create(
            user=purchase.user,
            action_type='purchase_product',
            description=f"Buyurtma bekor qildi: {purchase.product.name} (+{purchase.coins_spent} coin qaytarildi)"
        )

        notify_admins(
            f"❌ <b>Buyurtma bekor qilindi!</b>\n\n"
            f"👤 <b>{purchase.user.full_name}</b> (@{purchase.user.username})\n"
            f"📦 Mahsulot: <b>{purchase.product.name}</b>\n"
            f"🪙 Qaytarildi: <b>{purchase.coins_spent}</b> coin\n\n"
            f"📋 Buyurtma #{purchase.pk}"
        )

        if purchase.user.telegram_id:
            notify_user(
                purchase.user.telegram_id,
                f"❌ <b>Buyurtmangiz bekor qilindi</b>\n\n"
                f"📦 <b>{purchase.product.name}</b>\n"
                f"🪙 <b>{purchase.coins_spent}</b> coin balansingizga qaytarildi\n\n"
                f"📋 Buyurtma #{purchase.pk}"
            )

        Message.objects.create(
            recipient=purchase.user,
            title=f"❌ Buyurtma #{purchase.pk} bekor qilindi",
            content=f"'{purchase.product.name}' mahsuloti uchun buyurtmangiz bekor qilindi. {purchase.coins_spent} coin balansingizga qaytarildi.",
            message_type='system'
        )

    serializer = ProductPurchaseSerializer(purchase)
    return Response(serializer.data)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_comment(request, pk):
    product = get_object_or_404(Product, pk=pk)
    serializer = ProductCommentCreateSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    one_hour_ago = timezone.now() - timedelta(hours=1)
    recent_comment = ProductComment.objects.filter(
        user=request.user,
        created_at__gte=one_hour_ago
    ).exists()

    if recent_comment:
        return Response(
            {'error': "Siz 1 soatda faqat bitta izoh qoldirishingiz mumkin! ⏰"},
            status=status.HTTP_429_TOO_MANY_REQUESTS
        )

    comment = ProductComment.objects.create(
        product=product,
        user=request.user,
        content=serializer.validated_data['content']
    )

    if request.user.is_premium:
        request.user.add_coins(1, f"Mahsulotga izoh (Premium): {product.name}")
    else:
        request.user.remove_coins(1, f"Mahsulotga izoh yozish: {product.name}")

    ActivityLog.objects.create(
        user=request.user,
        action_type='comment_product',
        description=f"Mahsulotga izoh qoldirdi: {product.name}"
    )

    return Response(ProductCommentSerializer(comment).data, status=status.HTTP_201_CREATED)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def request_premium(request):
    serializer = PremiumRequestSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    plan = serializer.validated_data['plan']

    pending = PremiumRequest.objects.filter(user=request.user, status='pending').first()
    if pending:
        return Response(
            {'error': "Sizda allaqachon kutilayotgan Premium so'rov bor!"},
            status=status.HTTP_400_BAD_REQUEST
        )

    plan_info = PREMIUM_PLANS[plan]
    price = plan_info['price']

    if request.user.coins < price:
        return Response(
            {'error': f"Coinlaringiz yetarli emas! {plan_info['name']} Premium narxi: {price} coin"},
            status=status.HTTP_400_BAD_REQUEST
        )

    with transaction.atomic():
        request.user.coins -= price
        request.user.save(update_fields=['coins'])

        is_ext = (
            request.user.is_premium
            and request.user.premium_expires_at
            and request.user.premium_expires_at > timezone.now()
        )

        PremiumRequest.objects.create(
            user=request.user,
            plan=plan,
            is_extension=is_ext,
        )

        CoinTransaction.objects.create(
            user=request.user,
            amount=price,
            action='remove',
            reason=f"✅ Premium so'rov ({plan_info['name']}) - {price} coin"
        )

        ActivityLog.objects.create(
            user=request.user,
            action_type='purchase_product',
            description=f"Premium so'rov yuborildi: {plan_info['name']} ({price} coin)"
        )

        admins = CustomUser.objects.filter(role='admin')
        for admin in admins:
            Message.objects.create(
                sender=request.user,
                recipient=admin,
                title="Yangi Premium so'rov ✅",
                content=f"{request.user.full_name} {plan_info['name']} Premium ({price} coin) uchun so'rov yubordi. Dashboard > Premium boshqaruv bo'limidan tasdiqlang.",
                message_type='system'
            )

    label = "uzaytirish " if is_ext else ""
    return Response(
        {'message': f"Premium {label}so'rovingiz yuborildi! Admin tasdiqlashini kuting."},
        status=status.HTTP_201_CREATED
    )


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def premium_plans(request):
    pending = PremiumRequest.objects.filter(user=request.user, status='pending').first()
    return Response({
        'plans': PREMIUM_PLANS,
        'has_pending_request': pending is not None,
        'is_premium': request.user.is_premium,
    })
