from django.urls import path
from . import views

app_name = 'teacher'

urlpatterns = [
    # Dashboard
    path('', views.teacher_dashboard, name='dashboard'),
    path('statistics/', views.teacher_statistics, name='statistics'),
    path('export/', views.teacher_export, name='export'),

    # Öquvçilarim
    path('students/', views.teacher_my_students, name='my_students'),
    path('students/coins/', views.teacher_student_coins, name='student_coins'),
    path('students/add/', views.teacher_add_student, name='add_student'),
    path('students/remove/', views.teacher_remove_student, name='remove_student'),

    # Kurs sörovlari (yoziliş / çiqiş)
    path('requests/', views.teacher_course_requests, name='course_requests'),
    path('requests/<str:kind>/<int:pk>/<str:decision>/', views.teacher_review_request, name='review_request'),

    # Admin: öqituvçi amallari jurnali
    path('admin/actions/', views.admin_teacher_actions, name='admin_actions'),

    # Guruh çatlari
    path('group-chats/', views.teacher_group_chats, name='group_chats'),

    # Kurslarim
    path('courses/', views.teacher_courses, name='courses'),
    path('courses/<int:pk>/edit/', views.teacher_edit_course, name='edit_course'),

    # Daromadlarim
    path('earnings/', views.teacher_earnings, name='earnings'),

    # Test natijalari
    path('test-results/', views.teacher_test_results, name='test_results'),

    # Uyga vazifalar
    path('homeworks/', views.teacher_homeworks, name='homeworks'),
    path('homeworks/<int:pk>/grade/', views.teacher_grade_homework, name='grade_homework'),

    # Test yuklaş
    path('courses/<int:pk>/add-test/', views.teacher_add_test, name='add_test'),
    path('tests/<int:pk>/questions/', views.teacher_manage_questions, name='manage_questions'),
    path('tests/<int:pk>/questions/add/', views.teacher_add_question, name='add_question'),
    path('questions/<int:pk>/delete/', views.teacher_delete_question, name='delete_question'),
    path('tests/<int:pk>/import/', views.teacher_import_questions, name='import_questions'),
    path('tests/<int:pk>/generate-ai/', views.teacher_generate_ai_test, name='generate_ai_test'),

    # Sertifikatlarim
    path('certificates/', views.teacher_certificates, name='certificates'),
    path('certificates/<int:pk>/edit/', views.teacher_certificate_edit, name='certificate_edit'),
    path('certificates/<int:pk>/toggle/', views.teacher_certificate_toggle, name='certificate_toggle'),
    path('certificates/<int:pk>/delete/', views.teacher_certificate_delete, name='certificate_delete'),

    # Speaking vazifalar
    path('speaking/', views.teacher_speaking_tasks, name='speaking_tasks'),
    path('speaking/<int:pk>/grade/', views.teacher_grade_speaking, name='grade_speaking'),
    path('courses/<int:pk>/add-speaking/', views.teacher_add_speaking, name='add_speaking'),

    # Yakuniy test tölovlari
    path('final-test-payments/', views.teacher_final_test_payments, name='final_test_payments'),
    path('final-test-payments/<int:pk>/approve/', views.teacher_approve_final_payment, name='approve_final_payment'),
    path('final-test-payments/<int:pk>/reject/', views.teacher_reject_final_payment, name='reject_final_payment'),

    # AI Tekşiruvçi
    path('ai-checker/', views.teacher_ai_checker, name='ai_checker'),
    path('ai-checker/toggle/', views.teacher_ai_checker_toggle, name='ai_checker_toggle'),
    path('ai-checker/file-only-toggle/', views.teacher_file_only_toggle, name='file_only_toggle'),
]
